package ru.vsu.cs.KiselevaMaria;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        int[] arr = {1, 2, 4, 5, 6, 7, 9, 8};
        int[] arr1 = {143, 178888, 0, 22658, 111111111, 90};
        int[] arr2 = {10999, 321, 222, 146, 99, 22, 11, 4};
        int[] arr3 = {123, 65, 90, 843, 100, 6678, 32};

        int[] array = new int[30];
        for (int i = 0; i < array.length; i++) {
            array[i] = ((int)(Math.random() * 125) - 15);
            System.out.println(array[i]);
        }
        System.out.println("-----------------");
        Coursera.quickSortFirst(array, 0, array.length);
        for(int k=0; k< array.length; k++) {
            System.out.println(array[k]);
        }

        System.out.println("------------------");

        Coursera.quickSortFirst(arr, 0, arr.length);
        for(int n=0; n< arr.length; n++) {
            System.out.println(arr[n]);
        }
        System.out.println("------------------");
        Coursera.quickSortLast(arr1, 0, arr1.length);
        for(int i=0; i< arr1.length; i++) {
            System.out.println(arr1[i]);
        }
        System.out.println("--------------------");
        Integer[] arr4 = Arrays.stream(arr2).boxed().toArray(Integer[]::new);
        Coursera.quickSortMed(arr4, 0, arr2.length);
        for(int j=0; j< arr4.length; j++) {
            System.out.println(arr4[j]);
        }
    }
}
