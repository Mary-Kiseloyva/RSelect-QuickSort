package ru.vsu.cs.KiselevaMaria;

public class Random {
    public static int[] swap(int[] array, int i, int j) {                                    // Exchanges the values of i with the value of j
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
        return array;
    }


    public static int partition(int[] toPartition, int lo, int hi) {
        int val = toPartition[lo];
        int h = lo;

        for (int k = lo; k < hi ; k++) {
            if (toPartition[k] < val) {
                h = h + 1;
                toPartition = swap(toPartition, h, k);
            }
        }
        toPartition = swap(toPartition, lo, h);
        return h;
    }


    public static int random_partition(int[] toPartition, int lo, int hi) {
        java.util.Random rand = new java.util.Random();
        int k = rand.nextInt((hi - lo) + 1) + lo;

        toPartition = swap(toPartition, lo, k);
        return partition(toPartition, lo, hi);
    }


    public static int[] random_quicksort(int[] toPartition, int lo, int hi) {
        if (lo < hi) {
            int p = random_partition(toPartition, lo, hi);
            random_quicksort(toPartition, lo, p - 1);
            random_quicksort(toPartition, p + 1, hi);
        }
        return toPartition;
    }


    public static int random_select(int[] array, int i, int j, int median) {
        if (i < j) {
            int p = random_partition(array, i, j);
            if (median == p) {
                return p;
            }
            int p2 = -1;
            if (median < p) {
                p2 = random_select(array, i, p - 1, median);
            } else {
                p2 = random_select(array, p + 1, j, median);
            }
            if (median == p2) {
                return p2;
            }
        }
        return 0;
    }

}
