package ru.vsu.cs.KiselevaMaria;

public class Main {

    public static void main(String[] args) {
        int[] A = {5, 3, 2, 6, 3, 5, 10, 8, 9, 7, 10}; // 2 3 3 5 5 6 7 8 9 10 10
        for (int i = 0; i < A.length; i++) {
            int d = RSelect(A.clone(), 0, A.length - 1, i);
            System.out.println(d);
        }
    }

    public static int Partition(int[] A, int l, int r, int index) {
        int p = A[index];
        int i = l;
        int temp = A[index];
        A[index] = A[r];
        A[r] = temp;
        for (int j = l; j <= r; j++) {
            if (A[j] < p) {
                int x = A[i];
                A[i] = A[j];
                A[j] = x;
                i++;
            }
        }
        int k = A[r];
        A[r] = A[i];
        A[i] = k;

        return i;
    }


    public static int RSelect(int[] A, int l, int r, int i) { // сортируем на массиве
        if (l == r) {
            return A[l];
        }
        int p = (int) (Math.random() * (r - l + 1)) + l;  // выбираем случайный элемент от l до r
        p = Partition(A, l, r, p);
        if (i == p) return A[p];
        else if (i > p) return RSelect(A, p + 1, r, i);
        else return RSelect(A, l, p - 1, i);
    }
    }

